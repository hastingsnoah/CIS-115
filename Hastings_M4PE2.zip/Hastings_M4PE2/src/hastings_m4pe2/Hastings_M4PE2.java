package hastings_m4pe2;

/**
 *Hastings Noah
 * M4PE2
 * 09-14-2021
 * Calculate tip, tax, and total of a meal
 */
import java.util.Scanner;
public class Hastings_M4PE2 
{
    public static void main(String[] args) 
    {
        double food=0;double tip=0;double tax=0; double total=0;
        double TaxRate=.07;
        double TipRate=.15;
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Enter charge for food: ");
        food= keyboard.nextDouble();
        tip=food*TipRate;
        tax=food*TaxRate;
        total= food+tax+tip;
        System.out.println("Tip: $"+tip);
        System.out.println("Tax: $"+tax);
        System.out.println("Total: $"+total);
        
    }
    
}
