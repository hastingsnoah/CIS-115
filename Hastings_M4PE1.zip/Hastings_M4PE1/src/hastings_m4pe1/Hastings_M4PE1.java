package hastings_m4pe1;
/**
 * @Noah Hastings
 * M4PE1
 * 09-19-2021
 * This program is to calculate the acre size of an inputed tract size
 */
import java.util.Scanner;
public class Hastings_M4PE1 
{
    public static void main(String[] args) 
    {
     double acres=0;
     double tractsize=0;
     int SQ_FEET_PER_ACRE=43560;
     Scanner keyboard = new Scanner (System.in);
     System.out.println("Enter the number of square feet in the tract: ");
     tractsize= keyboard.nextDouble();
     acres= tractsize/SQ_FEET_PER_ACRE;
     System.out.println("The size of that tract is "+acres+"acres.");
    }
}